public class A
{
	 A()
	 {
	 	}
	 void A()
	 {
	 	System.out.println("Class A");
	 }
	 public static void main(String [] args)
	 {
	 	 new A();
	 	}
	 
}