class Value{
	 int b;  //2
	static int c;//1
	Value(){   //3
		c=15;
	}
	Value(int i){
		c=i;
	}
	static void inc(){
		c++;
	}
}
class Count2{
	public static void prt(String s){
		System.out.println(s);
	}
	Value v=new Value(10);
	static Value v1,v2;
	static{
		prt("v1.c="+v1.c+"  v2.c="+v2.c);
		v1=new Value(27);
		prt("v1.c="+v1.c+"  v2.c="+v2.c);
		v2=new Value(15);
		prt("v1.c="+v1.c+"  v2.c="+v2.c);
		
	}
	public static void main(String[] args)
	{
		value ct=new value();
		prt("ct.c="+ct.v.c);
		prt("v1.c="+v1.c+"  v2.c="+v2.c);
		v1.inc();
		prt("v1.c="+v1.c+"  v2.c="+v2.c);
		prt("ct.c="+ct.v.c);
	}
	
}
