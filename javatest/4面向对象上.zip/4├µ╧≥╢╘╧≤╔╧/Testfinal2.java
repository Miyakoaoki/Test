public class Testfinal2 extends Testfinal
{
	public void f1()
	{
		 System.out.println("testfinal father method ");
	}
	
//	public void f2()
//	{
//		System.out.println("fdsfsd");
//	}
	
	public static void main(String [] args){
		Testfinal2 t=new Testfinal2();
		t.f1();
		t.f2();
		t.f3();
		t.f4();
	}
	
}
