public class changetrave{


	public static void tripleValue(double x) 
       {     x = 3 * x;   
         System.out.println(x);
       
        }
 
   public static void main(String [] args)
   {
   	   	double percent = 10;
         tripleValue(percent);
   }
}