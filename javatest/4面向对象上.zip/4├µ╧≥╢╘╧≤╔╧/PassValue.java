public class PassValue {
private static int a;
//	 public int c;
	 public static void main(String [] args) {
		  modify(a);
	//	  PassValue b=new PassValue();
	//	  b.modify(a);
		  
		  System.out.println(a);
	 }
	 public static void modify(int a) {
	//	c=a;
		a++;
	 }
}
