 class Simple{
	static  void go()
	{
		System.out.println("go ....");
	}
	
}

public class Cal{
	public static void main(String [] args)
	{
	 
	   	Simple.go();
	}
	
}