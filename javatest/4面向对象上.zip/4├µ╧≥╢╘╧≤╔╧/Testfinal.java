public class Testfinal{
	public void f1(){
		System.out.println("f1");
	}
	public final void f2(){
		System.out.println("f2");
		
	}
	public void f3()
	{
		System.out.println("f3");
	}
	private void f4()
	{
		System.out.println("f4");
	}
	
}

