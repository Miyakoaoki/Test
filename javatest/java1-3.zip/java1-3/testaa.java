public class testaa{
	public static void main(String [] args)
	{
		System.out.println(5.14%3);
	}
}