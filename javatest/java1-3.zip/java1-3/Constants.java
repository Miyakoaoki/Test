import java.io.*;

public class Constants
{
  public static void main(String[] args)
  {
      final double PI=3.1415926;
     double r=3.4;
     System.out.println("Area of circle i"+PI*r*r );
  }
}
