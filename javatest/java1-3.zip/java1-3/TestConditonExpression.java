class TestConditonExpression{
	public static void main(String [] args)
	{
	//	float sum=1.5f;
	//	int num=2;
	//	System.out.println((sum<3?1:num/sum));
				
		
		int num=3,sum=2;
		System.out.println((sum<3?1:num/sum));
		
		}

	}