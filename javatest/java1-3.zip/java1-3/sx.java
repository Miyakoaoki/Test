public class sx
{
	public static void main(String [] args)
	 {
	 
	 	int a1=2,a2=2;
	 	int b=(++a1)*2;
	 	int cl=(a2++)*2;
	 	System.out.println("b="+b);
	 	System.out.println("c1="+cl);	 	
	 	
	 	int m=7;
		int n=7;
		int d=2*++m; 
		int e=2*n++; 
	    System.out.println("d="+d);
	 	System.out.println("e="+e);	 
	 	System.out.println("m="+m);
	 	System.out.println("n="+n);	 	

	 	System.out.println(9%2);
	 	System.out.println(3.14%2);
	 	
	 	}
	
	}