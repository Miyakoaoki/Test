public class TestLogicSymbole
{
	public static void main(String args [])
	 {
	 	int out;
	 	out=10;
	 	boolean b1=false;
	 // if((b1==true)&(out+=10)==20)
	 //	if((b1==true)&&(out+=10)==20)
	 // if((b1==false)&&(out+=10)==20)
	  if((b1==false)&(out+=10)==20)
	 	   {
	 	   	 System.out.println("==,out="+out);
	 	   	 
	 	   }
	 	else 
	 	  {
	 	  	 System.out.println("!=,out="+out);
	 	  	}
	 	
	 	}
	 
	}