package com.run;
import com.resource.*;
public class RunPlane
{
	public static void main(String args[]){
       FighterPlane2 fp = new FighterPlane2();
	   fp.name ="shusan";
	   fp.missileNum = 6;	 
	   fp.fire();
   }
}
