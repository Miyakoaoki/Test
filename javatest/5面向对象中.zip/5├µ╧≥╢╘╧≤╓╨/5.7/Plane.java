class  Plane
{
  protected String name;
  public void setName(String _name){
      name = _name;
  }
  public String getName(String _name){
     return name;
  }
}
