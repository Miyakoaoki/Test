public class test
{
	private double salary;
	public test()
	{
		System.out.println("test!!!!");
		}
	
	public static void main(String args[])
	{
		 test a=new test();
		 
		 a.salary=-1500;
		 System.out.println(a.salary);
	}
}