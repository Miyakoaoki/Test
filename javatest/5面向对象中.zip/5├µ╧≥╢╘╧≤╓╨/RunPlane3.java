package com.run;
import com.resource.*;
public class RunPlane3
{
	  public static void main(String args[]){      
	   System.out.println(FighterPlane3.name);
   }
} 
