package com.run;
import com.resource.*;
public class RunPlane4
{	public static void main(String args[]){
       FighterPlane4 fp;
	      fp=FighterPlane4.getInstance("��35",6);
	      fp.fire();
     }
}
