class value{
	int i=1;
}
public class FinalData{
	final int i1=9;
	static final int I2=99;
	public static final int I3=39;
	final int i4=(int)(Math.random()*20);
	static final int i5=(int)(Math.random()*20);
	value v1=new value();
	final value v2=new value();
	static final value v3=new value();
	final int [] a={1,2,3,4,5,6};
	public void print(String id){
		System.out.print(id);
	}
	
	
}