package com.resource;
public class FighterPlane3
{
   public static  String name="��35";     
} 
